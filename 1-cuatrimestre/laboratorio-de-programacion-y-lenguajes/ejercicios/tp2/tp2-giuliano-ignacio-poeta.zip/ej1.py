"""
1. Introducción a Variables y Tipos de Datos: Solicite al usuario que ingrese su nombre y 
edad. Posteriormente, genere un mensaje que diga: "Estimado [nombre], el año próximo 
usted tendrá [edad+1] años".
"""

nombre = input("Ingrese su nombre: ")
edad = int(input("Ingrese su edad: "))
print(f"Estimado {nombre}, el año próximo usted tendrá {edad + 1} años")