"""
3. Estructuras de Control - Bucles con For: Implemente un programa que imprima los 
números del 1 al 10 empleando un bucle for. 
"""

for i in range(1, 11):
    print(i)