"""
5. Funciones: Defina una función llamada maximo que reciba dos números como 
argumentos y retorne el mayor de ellos. No se debe utilizar la función max() de Python 
para este ejercicio. 
"""

def maximo(a, b):
    return a if a > b else b